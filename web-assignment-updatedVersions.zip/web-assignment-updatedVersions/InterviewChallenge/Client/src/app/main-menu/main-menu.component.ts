import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-main-menu',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div>
      <h1 class="text-2xl font-bold mb-8 text-center lg:text-left">Christie Projector</h1>
      <div class="space-y-4">
        <button (click)="showInputSelection.emit()" [disabled]="!isPoweredOn" [class.opacity-50]="!isPoweredOn"
          class="w-full flex items-center justify-center gap-2 rounded-lg bg-[var(--active-background)] hover:bg-[var(--primary-600)] transition-colors duration-300 text-white font-bold py-3 px-4">
          <span class="material-symbols-outlined">input</span>
          <span>Input Select</span>
        </button>
        <div class="grid grid-cols-2 gap-4">
          <button (click)="powerToggle.emit()"
            class="flex items-center justify-center gap-2 rounded-lg bg-[var(--neutral-800)] hover:bg-[var(--neutral-700)] transition-colors duration-300 text-white font-semibold py-3 px-4">
            <span class="material-symbols-outlined">power_settings_new</span>
            <span>Power</span>
          </button>
          <button (click)="showSettings.emit()"
            class="flex items-center justify-center gap-2 rounded-lg bg-[var(--neutral-800)] hover:bg-[var(--neutral-700)] transition-colors duration-300 text-white font-semibold py-3 px-4">
            <span class="material-symbols-outlined">settings</span>
            <span>Settings</span>
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class MainMenuComponent {
  @Input() isPoweredOn: boolean;
  @Output() powerToggle = new EventEmitter<void>();
  @Output() showInputSelection = new EventEmitter<void>();
  @Output() showSettings = new EventEmitter<void>();
}