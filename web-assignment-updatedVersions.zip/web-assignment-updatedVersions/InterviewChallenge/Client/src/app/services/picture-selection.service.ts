import { Injectable } from '@angular/core';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import { CommandHandler, CommandFactory } from './command-factory';
import { BackendCommunicationService } from './backend-communication.service';

export class DropDownOption {
  constructor(
    public index: number,
    public label: string,
    public value: string
  ) {}
}

export class DropDownData {
  constructor(
    public options: DropDownOption[],
    public selectedIndex: number,
    public disabled: boolean
  ) {}
}

export interface InputSource {
  index: number;
  label: string;
  value: string;
  active: boolean;
  icon?: string;
  image?: string;
  disabled: boolean;
}

export type ControlPanel = 'focus' | 'keystone' | 'color' | 'brightness' | 'audio' | 'video' | 'general' | 'network' | null;

@Injectable({
  providedIn: 'root',
})
export class PictureSelectionService {
  public static GET_PICTURE_SELECTOR: string = 'pictures:getSelector';
  public static UPDATE_PICTURE_SELECTOR: string = 'pictures:update';

  private commandCollection: Map<string, CommandHandler<any>>;
  private _inputSources$: BehaviorSubject<InputSource[]> = new BehaviorSubject<InputSource[]>([]);
  public readonly inputSources$: Observable<InputSource[]> = this._inputSources$.asObservable();

  constructor(private communicationServer: BackendCommunicationService) {
    this.commandCollection = new Map<string, CommandHandler<any>>();
    this.initUpdates();
  }

  private initUpdates(): void {
    // Get the initial data and publish it
    this.getPictureSelectorData().then(initialData => {
      const processedInputs = this.processData(initialData);
      this._inputSources$.next(processedInputs);
    });

    // Register for real-time push notifications from the backend
    this.communicationServer.registerUpdateHandler(PictureSelectionService.UPDATE_PICTURE_SELECTOR, (updateData: DropDownData) => {
      // Find the currently active options to get the full options array
      const currentOptions = this._inputSources$.getValue();
      const processedInputs = this.processData(updateData);
      this._inputSources$.next(processedInputs);
    });
  }

  // A public method to set the input and get the correct control panel
  public async setInputSource(selectedSource: InputSource): Promise<ControlPanel> {
    try {
      await this.communicationServer.sendCommand('pictures:setSelector', { selectedIndex: selectedSource.index });
      return this.getControlPanel(selectedSource.label);
    } catch (error) {
      console.error('Failed to set input source:', error);
      return null;
    }
  }

  // Private helper to process the raw backend data
  private processData(data: DropDownData): InputSource[] {
    const { options, selectedIndex } = data;
    return options.map((option: any, index: number) => ({
      ...option,
      name: option.label,
      icon: this.getIcon(option.label),
      image: this.getImageUrl(option.value),
      active: index === selectedIndex,
    }));
  }

  private getPictureSelectorData(): Promise<any> {
    return this.communicationServer.sendCommand(PictureSelectionService.GET_PICTURE_SELECTOR);
  }

  // Helper function to map an input label to a Material Symbols icon.
  private getIcon(label: string): string {
    switch (label) {
      case 'Audio': return 'volume_up';
      case 'Boxer': return 'lens';
      case 'CP4230': return 'videocam';
      case 'LW551i': return 'monitor';
      case 'MicroTiles LED': return 'grid_on';
      case 'Q-Series-main': return 'tv';
      case 'Spyder X80': return 'lan';
      default: return 'help_outline';
    }
  }

  // Helper function to construct the image URL for an input source.
  private getImageUrl(value: string): string {
    return `assets/${value}`;
  }

  // Helper function to get the control panel based on a label.
  private getControlPanel(label: string): ControlPanel {
    switch (label) {
      case 'Audio': return 'audio';
      case 'Boxer': return 'focus';
      case 'CP4230': return 'video';
      case 'LW551i': return 'general';
      case 'MicroTiles LED': return 'general';
      case 'Q-Series-main': return 'general';
      case 'Spyder X80': return 'network';
      default: return null;
    }
  }
}