import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ColorControlsComponent } from './color-controls.component';

describe('ColorControlsComponent', () => {
  let component: ColorControlsComponent;
  let fixture: ComponentFixture<ColorControlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ColorControlsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ColorControlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
