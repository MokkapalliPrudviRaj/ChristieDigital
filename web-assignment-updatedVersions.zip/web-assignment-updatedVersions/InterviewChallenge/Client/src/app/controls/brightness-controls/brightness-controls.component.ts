import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-brightness-controls',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div>
      <h3 class="text-lg font-medium text-white">Brightness</h3>
      <div class="space-y-4">
        <div class="flex items-center justify-between text-sm">
          <label class="font-medium text-gray-300" for="brightness-level">Level</label>
          <span class="text-gray-400">50</span>
        </div>
        <input class="custom-slider h-2 w-full cursor-pointer appearance-none rounded-full bg-gray-700"
          id="brightness-level" type="range" value="50" />
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class BrightnessControlsComponent {}