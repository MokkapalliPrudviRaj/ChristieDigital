import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KeystoneControlsComponent } from './keystone-controls.component';

describe('KeystoneControlsComponent', () => {
  let component: KeystoneControlsComponent;
  let fixture: ComponentFixture<KeystoneControlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [KeystoneControlsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(KeystoneControlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
