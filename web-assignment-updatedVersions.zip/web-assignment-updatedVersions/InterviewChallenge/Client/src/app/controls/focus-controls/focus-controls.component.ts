import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-focus-controls',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div>
      <h3 class="text-lg font-medium text-white">Focus</h3>
      <button
        class="flex w-full items-center justify-center gap-2 rounded-md bg-[var(--primary-600)] px-4 py-3 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-[var(--primary-500)]">
        <span class="material-symbols-outlined">auto_awesome</span>
        <span>Auto-Focus</span>
      </button>
      <div class="space-y-4 mt-4">
        <div class="flex items-center justify-between text-sm">
          <label class="font-medium text-gray-300" for="manual-focus">Manual Focus</label>
          <span class="text-gray-400">50</span>
        </div>
        <input class="custom-slider h-2 w-full cursor-pointer appearance-none rounded-full bg-gray-700"
          id="manual-focus" type="range" value="50" />
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class FocusControlsComponent {}