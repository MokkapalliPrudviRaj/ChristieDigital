import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FocusControlsComponent } from './focus-controls.component';

describe('FocusControlsComponent', () => {
  let component: FocusControlsComponent;
  let fixture: ComponentFixture<FocusControlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FocusControlsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FocusControlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
