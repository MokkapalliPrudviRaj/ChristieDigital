import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ControlPanel } from '../services/picture-selection.service';
import { FocusControlsComponent } from './focus-controls/focus-controls.component';
import { KeystoneControlsComponent } from './keystone-controls/keystone-controls.component';
import { ColorControlsComponent } from './color-controls/color-controls.component';
import { BrightnessControlsComponent } from './brightness-controls/brightness-controls.component';

@Component({
  selector: 'app-controls',
  standalone: true,
  imports: [CommonModule, FormsModule, FocusControlsComponent, KeystoneControlsComponent, ColorControlsComponent, BrightnessControlsComponent],
  template: `
    <div class="flex flex-col flex-grow">
      <nav class="flex flex-col gap-4">
        <div class="flex items-center gap-3 flex-shrink-0">
          <span class="material-symbols-outlined text-3xl text-[var(--primary-500)]">settings_remote</span>
          <h1 class="text-2xl font-bold text-white">Controls</h1>
        </div>
        <button (click)="back.emit()"
          class="flex w-full items-center gap-3 rounded-md px-3 py-2 text-left text-gray-400 hover:bg-gray-800 hover:text-white">
          <span class="material-symbols-outlined">arrow_back</span>
          <span>Back</span>
        </button>
      </nav>

      <div class="mt-8 overflow-y-auto max-h-80 custom-scrollbar flex-grow space-y-6">
        <app-focus-controls *ngIf="selectedControl === 'focus'"></app-focus-controls>
        <app-keystone-controls *ngIf="selectedControl === 'keystone'"></app-keystone-controls>
        <app-color-controls *ngIf="selectedControl === 'color'"></app-color-controls>
        <app-brightness-controls *ngIf="selectedControl === 'brightness'"></app-brightness-controls>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class ControlsComponent {
  @Input() selectedControl: ControlPanel;
  @Output() back = new EventEmitter<void>();
}