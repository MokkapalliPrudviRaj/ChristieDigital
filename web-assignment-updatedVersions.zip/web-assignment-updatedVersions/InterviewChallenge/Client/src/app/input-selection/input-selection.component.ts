import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgFor, NgIf } from '@angular/common';
import { InputSource } from '../services/picture-selection.service';

@Component({
  selector: 'app-input-selection',
  standalone: true,
  imports: [CommonModule, NgFor],
  template: `
    <div>
      <h1 class="text-3xl font-bold mb-8">Input</h1>
      <div class="mb-4">
        <button (click)="back.emit()"
          class="flex w-full items-center gap-3 rounded-md px-3 py-2 text-left text-gray-400 hover:bg-gray-800 hover:text-white">
          <span class="material-symbols-outlined">arrow_back</span>
          <span>Back</span>
        </button>
      </div>
      <nav class="space-y-2 mb-6 max-h-64 overflow-y-auto custom-scrollbar">
        <a *ngFor="let source of inputSources" (click)="selectInput.emit(source)"
          [ngClass]="{ 'bg-[var(--active-background)] text-white font-semibold shadow-lg': source.active, 'hover:bg-[var(--hover-background)] transition-colors': !source.active }"
          class="flex items-center gap-3 px-4 py-3 rounded-lg cursor-pointer">
          <span class="material-symbols-outlined"
            [ngClass]="{ 'text-white': source.active, 'text-[var(--muted-text-color)]': !source.active }">{{ source.icon }}</span>
          <span>{{ source.label }}</span>
        </a>
      </nav>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class InputSelectionComponent {
  @Input() inputSources: InputSource[];
  @Output() back = new EventEmitter<void>();
  @Output() selectInput = new EventEmitter<InputSource>();
}