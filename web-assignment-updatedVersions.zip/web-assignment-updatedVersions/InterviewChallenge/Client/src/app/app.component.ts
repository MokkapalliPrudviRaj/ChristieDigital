import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PictureSelectionService, InputSource, ControlPanel } from './services/picture-selection.service';
import { Subscription } from 'rxjs';

// Define the different views for the Control Panel
type ViewState = 'main-menu' | 'input-selection' | 'controls';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, NgIf, NgFor],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent implements OnInit {
  // --- COMPONENT PROPERTIES ---
  public currentView: ViewState = 'main-menu';
  public inputSources: InputSource[] = [];
  public selectedImage: string = '';
  public selectedLabel: string = '';
  public selectedControl: ControlPanel = null;
  public version: string = '1.0.0';
  public year: number = new Date().getFullYear();
  public isPoweredOn: boolean = false;
  private subscriptions: Subscription = new Subscription();

  constructor(private pictureSelectionService: PictureSelectionService, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    // Subscribe to the observable to receive all updates
    this.subscriptions.add(this.pictureSelectionService.inputSources$.subscribe(inputs => {
      this.inputSources = inputs;
      this.updateImage();
      this.cdr.detectChanges();
    }));
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  // --- COMPONENT METHODS ---
  public async selectInput(selectedSource: InputSource): Promise<void> {
    if (!this.isPoweredOn) {
      return;
    }

    // Update local state before the service call
    this.inputSources.forEach(source => {
      source.active = (source === selectedSource);
    });
    this.updateImage();
    this.cdr.detectChanges(); // Trigger change detection for the image update

    // Call the service to set the input and get the correct control type
    this.selectedControl = await this.pictureSelectionService.setInputSource(selectedSource);

    // Only change the view if a valid control panel is returned
    if (this.selectedControl) {
      this.currentView = 'controls';
      this.cdr.detectChanges(); // Trigger change detection for the view change
    } else {
      this.currentView = 'input-selection';
      console.warn('No specific control panel found for this input.');
    }
  }

  // All other methods remain the same
  selectControl(control: ControlPanel): void {
    this.selectedControl = control;
  }

  private updateImage(): void {
    const activeSource = this.inputSources.find(source => source.active);
    if (activeSource) {
      this.selectedImage = activeSource.image || '';
      this.selectedLabel = activeSource.label || '';
    }
  }

  showMainMenu(): void {
    this.currentView = 'main-menu';
    this.cdr.detectChanges();
  }

  showInputSelection(): void {
    if (this.isPoweredOn) {
      this.currentView = 'input-selection';
      this.cdr.detectChanges();
    }
  }

  onPower(): void {
    this.isPoweredOn = !this.isPoweredOn;

    if (this.isPoweredOn) {
      this.updateImage();
    } else {
      this.selectedImage = '';
      this.selectedLabel = '';
      this.currentView = 'main-menu';
    }
    this.cdr.detectChanges();
  }

  onSettings(): void {
    console.log('Settings button clicked!');
  }
}