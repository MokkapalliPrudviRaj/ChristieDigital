Client (GUI/Angular app)
Requires that npm is installed(Downlaod node and run 'npm install -g @angular/cli'(Installing Angular CLI) in shell)
1. navigate to the Client directory (where you found this README)
2. open a shell (shift+right click -> Open Powershell in Windows)
3. npm install	(to install the required packages)
4. ng serve --open (to start the app)
5. http://localhost:4200 should automatically open in your browser

---

Tailwind CSS Setup

This project uses Tailwind CSS for styling. If you are running this project for the first time, you will need to install and configure Tailwind before starting the application.

1.Install Dependencies: Run the following command in your terminal to install Tailwind CSS and its peer dependencies.
    npm install -D tailwindcss postcss autoprefixer

2.Initialize Configuration Files:** Generate the `tailwind.config.js` and `postcss.config.js` files.

    npx tailwindcss init -p

3.Configure Template Paths:** Open `tailwind.config.js` and add the paths to all of your template files. This allows Tailwind to find and process all your classes.

    ```javascript
    /** @type {import('tailwindcss').Config} */
    module.exports = {
      content: [
        "./src/**/*.{html,ts}",
      ],
      theme: {
        extend: {},
      },
      plugins: [],
    }
    ```

4.  **Add Tailwind Directives to CSS:** Open your main CSS file (e.g., `src/styles.scss` or `src/styles.css`) and add the `@tailwind` directives.

    ```css
    @tailwind base;
    @tailwind components;
    @tailwind utilities;
    ```
    
The `ng serve` command should now correctly process your Tailwind CSS classes.