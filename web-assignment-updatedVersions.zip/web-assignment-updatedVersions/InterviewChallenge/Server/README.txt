Requires Yarn to be installed(download node and run 'npm install --global yarn' (Installing yarn))

Server
1. navigate to the Server directory (where you found this README)
2. open a shell (shift+right click -> Open Powershell on Windows)
3. yarn (to install/update the required npm packages)
4. yarn run watch (to actually run the server)
5. The socket is being served up at ws://localhost:3000
(the client UI will automatically use this and should not require further user interaction)